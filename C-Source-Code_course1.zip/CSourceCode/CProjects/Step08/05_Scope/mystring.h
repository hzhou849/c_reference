#define MAXSTRLEN 200
int readln(char[], int);
char * findsubstring(char[], char[]);
// int searchstring(char[], char[]);