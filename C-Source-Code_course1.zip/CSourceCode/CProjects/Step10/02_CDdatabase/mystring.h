#define MAXSTRLEN 200
int readln(char[]);
int searchstring(char[], char[]);