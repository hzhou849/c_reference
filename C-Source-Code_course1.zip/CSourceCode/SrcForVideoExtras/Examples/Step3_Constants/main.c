#include <stdio.h>
#include <math.h>

int main(int argc, char **argv)
{
	const double PI = 3.14159;
	// const double PI = 55.5;
	printf("%f\n", PI);
	printf("%.10f\n", M_PI);
	return 0;
}
